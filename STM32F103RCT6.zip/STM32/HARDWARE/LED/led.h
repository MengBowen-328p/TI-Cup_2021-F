#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LEDR PCout(6)// PB5
#define LEDY PCout(7)// PE5	
#define LEDG PCout(8)// PE5	

void LED_Init(void);//��ʼ��

		 				    
#endif
