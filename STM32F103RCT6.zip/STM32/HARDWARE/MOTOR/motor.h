#ifndef __MOTOR_H
#define __MOTOR_H	 
#include "sys.h"

#define A1 PCout(10)// PE5	
#define A2 PCout(11)// PE5	

#define B1 PAout(4)// PE5	
#define B2 PAout(5)// PE5	

#define C1 PBout(7)// PE5	
#define C2 PBout(6)// PE5	

#define D1 PBout(8)// PE5	
#define D2 PBout(9)// PE5	

void MOTOR_Init(void);//��ʼ��
void MOTOR_PWM_Init(u16 arr,u16 psc);
void TIM1_DJ_PWM_Init(u16 arr,u16 psc);
		 				 
						 
#endif
